# Syscomtec Switcher Module

A module to control the Syscomtec Switchers.

Supported Modesl: SCT-SWKVM411-H2U3

## Configuration

| Option      | Description                |
| ----------- | -------------------------- |
| Target IP   | Destination Host name / IP |
| Target Port | Destination port           |
| Password    | Password for Login         |

## Actions

| Action      | Description                         |
| ----------- | ----------------------------------- |
| Route Video | Routes Input to Output              |
| Standway    | Puts the Switcher into Standby mode |
| Wake        | Wakes the Switcher from Standby     |

## Variables

| Variable                             | Description                       | Values                |
| ------------------------------------ | --------------------------------- | --------------------- |
| $(syscomtec-switcher:input_1)        | Label of input 1                  | Always Input 1        |
| $(syscomtec-switcher:input_2)        | Label of input 2                  | Always Input 2        |
| $(syscomtec-switcher:input_3)        | Label of input 3                  | Always Input 3        |
| $(syscomtec-switcher:input_4)        | Label of input 4                  | Always Input 4        |
| $(syscomtec-switcher:output_1)       | Label of output 1                 | Always Output 1       |
| $(syscomtec-switcher:output_1_input) | Label of input routed to output 1 | Input 1-4             |
| $(syscomtec-switcher:standby)        | Standby                           | true or false Boolean |
